puts "Voer je naam in:"

naam = gets.chomp

puts "Je naam is: #{naam}."
