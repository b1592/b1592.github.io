puts "Voer je naam in:"

naam = gets.chomp

puts "Hallo, #{naam}"
