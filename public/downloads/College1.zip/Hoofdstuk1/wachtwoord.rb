puts "Voer het wachtwoord in:"

wachtwoord = gets.chomp

if wachtwoord == "fluffy"
  puts "Correct ingevoerd."
else
  puts "Niet goed ingevoerd."
end
