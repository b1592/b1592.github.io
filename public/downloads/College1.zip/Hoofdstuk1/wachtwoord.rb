puts "Voer het wachtwoord in:"
input = gets.chomp

if input == "123456"
  puts "Dat is correct."
else
  puts "Incorrect ingevoerd."
end
