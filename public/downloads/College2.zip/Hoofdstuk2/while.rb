counter = 0

while counter <= 10
  puts "De counter is nu #{counter}."
  counter = counter + 1
end
