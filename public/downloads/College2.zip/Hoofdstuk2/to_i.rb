puts "Typ een getal:"
getal = gets.chomp.to_i

puts getal * 4
