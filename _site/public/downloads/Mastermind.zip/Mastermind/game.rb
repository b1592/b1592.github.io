class Game
  def initialize
  end

  def guess(code)
  end

  def over?
  end
end