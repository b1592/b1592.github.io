def build_cipher(shift)
	# Maak een hash met daarin elke letter van het alfabet en de letters waardoor
	# deze moeten worden vervangen

end

def encrypt(message, shift)
	# Neem een bericht en codeer deze met de hash uit de build_cipher-functie met
	# een gegeven shift

end

def decrypt(message, shift)
	# Decodeer een bericht weer, als je de shift weet. Hint: dit kan vrij kort!

end