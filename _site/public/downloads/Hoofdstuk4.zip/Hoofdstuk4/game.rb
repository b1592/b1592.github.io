class Game
  def initialize
  end

  def play(move)
  end

  def over?
  end

  def current_player
  end

  def board
  end
end