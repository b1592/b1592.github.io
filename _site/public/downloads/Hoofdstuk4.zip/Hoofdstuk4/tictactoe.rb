require_relative "game"
require_relative "narrator"

game = Game.new
narrator = Narrator.new